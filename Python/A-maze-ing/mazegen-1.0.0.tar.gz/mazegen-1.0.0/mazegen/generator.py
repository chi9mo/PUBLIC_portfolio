"""Core maze generation logic.

Provides the MazeGenerator class that creates random mazes using
various algorithms. Each cell is encoded as a 4-bit integer where
each bit represents a wall (closed=1, open=0):

    bit 0 (LSB) = North
    bit 1       = East
    bit 2       = South
    bit 3 (MSB) = West
"""

from random import Random as _Random
import heapq
from typing import List, Tuple, Optional
from collections import deque

# Maze-specific seeded RNG factory (not for crypto use)
MazeRng = _Random


def create_rng(seed: Optional[int]) -> MazeRng:
    """Create a seeded RNG for maze generation."""
    return MazeRng(seed)


# Came-from map type used by solvers
CameFrom = dict[
    Tuple[int, int],
    Optional[Tuple[Tuple[int, int], int]]
]

# Wall direction constants (bit positions)
NORTH: int = 0x1
EAST: int = 0x2
SOUTH: int = 0x4
WEST: int = 0x8

ALL_WALLS: int = 0xF

# Direction offsets: (dx, dy) for each wall direction
DIRECTION_DELTA = {
    NORTH: (0, -1),
    EAST: (1, 0),
    SOUTH: (0, 1),
    WEST: (-1, 0),
}

# Opposite wall mapping
OPPOSITE = {
    NORTH: SOUTH,
    SOUTH: NORTH,
    EAST: WEST,
    WEST: EAST,
}

# Direction letters for path output
DIRECTION_LETTER = {
    NORTH: "N",
    EAST: "E",
    SOUTH: "S",
    WEST: "W",
}


def _build_edges(
    width: int, height: int,
) -> list[Tuple[int, int, int]]:
    """Build list of internal edges for Kruskal's algorithm."""
    edges: list[Tuple[int, int, int]] = []
    for y in range(height):
        for x in range(width):
            if x + 1 < width:
                edges.append((x, y, EAST))
            if y + 1 < height:
                edges.append((x, y, SOUTH))
    return edges


def _manhattan(
    a: Tuple[int, int], b: Tuple[int, int],
) -> int:
    """Manhattan distance between two grid cells."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _add_frontier(
    maze: "MazeGenerator",
    cx: int, cy: int,
    in_maze: set[Tuple[int, int]],
    walls: list[Tuple[int, int, int]],
) -> None:
    """Add frontier walls around a newly added cell."""
    for w, (dx, dy) in DIRECTION_DELTA.items():
        nx, ny = cx + dx, cy + dy
        if maze.in_bounds(nx, ny) and (nx, ny) not in in_maze:
            walls.append((cx, cy, w))


def _prim_try_carve(
    maze: "MazeGenerator",
    x: int, y: int, wall: int,
    in_maze: set[Tuple[int, int]],
) -> Optional[Tuple[int, int]]:
    """Try to carve a wall for Prim's; return new cell or None."""
    dx, dy = DIRECTION_DELTA[wall]
    nx, ny = x + dx, y + dy
    if not maze.in_bounds(nx, ny):
        return None
    if (nx, ny) in in_maze and (x, y) in in_maze:
        return None
    cell = (nx, ny) if (nx, ny) not in in_maze else (x, y)
    maze.carve(x, y, wall)
    in_maze.add(cell)
    return cell


class MazeGenerator:
    """Generate random mazes with configurable parameters.

    The maze is stored as a 2D grid of integers, where each integer
    encodes which walls are closed using 4 bits (NESW).

    Attributes:
        width: Number of cells horizontally.
        height: Number of cells vertically.
        grid: 2D list of wall-encoded cell values.
        seed: Random seed for reproducibility.
        perfect: Whether to generate a perfect maze.
        algorithm: Algorithm name used for generation.

    Example:
        >>> gen = MazeGenerator(10, 10, seed=42, perfect=True)
        >>> gen.generate(algorithm="recursive_backtracker")
        >>> print(gen.grid[0][0])  # top-left cell walls
        >>> path = gen.solve((0, 0), (9, 9))
        >>> print(path)  # e.g. 'SSEESEESS...'
    """

    def __init__(
        self,
        width: int,
        height: int,
        *,
        seed: Optional[int] = None,
        perfect: bool = True,
    ) -> None:
        """Initialize the maze generator.

        Args:
            width: Number of cells horizontally (must be > 0).
            height: Number of cells vertically (must be > 0).
            seed: Random seed for reproducibility.
            perfect: If True, generate a spanning-tree maze.

        Raises:
            ValueError: If width or height is not positive.
        """
        if width <= 0 or height <= 0:
            raise ValueError(
                f"Width and height must be positive, "
                f"got: {width}x{height}"
            )
        self.width: int = width
        self.height: int = height
        self.seed: Optional[int] = seed
        self.perfect: bool = perfect
        self.algorithm: str = "recursive_backtracker"
        self.grid: List[List[int]] = [
            [ALL_WALLS] * width for _ in range(height)
        ]
        self.pattern_cells: set[Tuple[int, int]] = set()

    def generate(
        self, algorithm: Optional[str] = None,
        rng: Optional[MazeRng] = None,
    ) -> None:
        """Generate the maze using the given algorithm.

        Args:
            algorithm: Algorithm name. If given, updates
                the stored algorithm attribute.
            rng: Optional Random instance for animation.
                If None, one is created from self.seed.

        Raises:
            ValueError: If the algorithm name is unknown.
        """
        if algorithm is not None:
            self.algorithm = algorithm
        if rng is None:
            rng = create_rng(self.seed)
        self.grid = [
            [ALL_WALLS] * self.width
            for _ in range(self.height)
        ]

        if self.algorithm == "recursive_backtracker":
            self._generate_recursive_backtracker(rng)
        elif self.algorithm == "kruskal":
            self._generate_kruskal(rng)
        elif self.algorithm == "prim":
            self._generate_prim(rng)
        else:
            raise ValueError(
                f"Unknown algorithm: {self.algorithm!r}"
            )

    def in_bounds(self, x: int, y: int) -> bool:
        """Check if coordinates are within maze bounds.

        Args:
            x: Column index.
            y: Row index.

        Returns:
            True if (x, y) is within bounds.
        """
        return 0 <= x < self.width and 0 <= y < self.height

    def _get_wall(self, x: int, y: int, wall: int) -> bool:
        """Check if a specific wall of a cell is closed.

        Args:
            x: Column index.
            y: Row index.
            wall: Wall direction constant (NORTH/EAST/SOUTH/WEST).

        Returns:
            True if the wall is closed.
        """
        return bool(self.grid[y][x] & wall)

    def _set_wall(
        self, x: int, y: int, wall: int, closed: bool
    ) -> None:
        """Set a wall state and update the neighbour's wall.

        Ensures neighbour consistency: when changing a cell's wall,
        the adjacent cell's opposing wall is also updated.

        Args:
            x: Column index.
            y: Row index.
            wall: Wall direction constant.
            closed: True to close the wall, False to open it.
        """
        if closed:
            self.grid[y][x] |= wall
        else:
            self.grid[y][x] &= ~wall

        dx, dy = DIRECTION_DELTA[wall]
        nx, ny = x + dx, y + dy
        if self.in_bounds(nx, ny):
            opp = OPPOSITE[wall]
            if closed:
                self.grid[ny][nx] |= opp
            else:
                self.grid[ny][nx] &= ~opp

    def carve(self, x: int, y: int, wall: int) -> None:
        """Open a wall between a cell and its neighbour.

        Args:
            x: Column index of the cell.
            y: Row index of the cell.
            wall: Wall direction to open.
        """
        self._set_wall(x, y, wall, False)

    def _generate_recursive_backtracker(
        self, rng: MazeRng,
    ) -> None:
        """Generate a perfect maze via iterative DFS backtracker.

        Uses an explicit stack instead of recursion to avoid
        stack overflow on large mazes.
        """
        visited: set[Tuple[int, int]] = set()
        sx: int = rng.randint(0, self.width - 1)
        sy: int = rng.randint(0, self.height - 1)
        stack: list[Tuple[int, int]] = [(sx, sy)]
        visited.add((sx, sy))

        while stack:
            x, y = stack[-1]
            neighbours: list[Tuple[int, int, int]] = []
            for wall, (dx, dy) in DIRECTION_DELTA.items():
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in visited
                ):
                    neighbours.append((nx, ny, wall))

            if neighbours:
                rng.shuffle(neighbours)
                nx, ny, wall = neighbours[0]
                self.carve(x, y, wall)
                visited.add((nx, ny))
                stack.append((nx, ny))
            else:
                stack.pop()

    def _generate_kruskal(
        self, rng: MazeRng,
    ) -> None:
        """Generate a perfect maze using Kruskal's algorithm.

        Treats each cell as a node and internal walls as edges.
        Randomly picks walls to remove, merging sets via union-find.
        """
        parent: dict[Tuple[int, int], Tuple[int, int]] = {}
        rank: dict[Tuple[int, int], int] = {}

        for y in range(self.height):
            for x in range(self.width):
                parent[(x, y)] = (x, y)
                rank[(x, y)] = 0

        def find(
            n: Tuple[int, int],
        ) -> Tuple[int, int]:
            """Find the root of the set containing n."""
            while parent[n] != n:
                parent[n] = parent[parent[n]]
                n = parent[n]
            return n

        def union(
            a: Tuple[int, int], b: Tuple[int, int]
        ) -> bool:
            """Union two sets. Return True if merged."""
            ra, rb = find(a), find(b)
            if ra == rb:
                return False
            if rank[ra] < rank[rb]:
                ra, rb = rb, ra
            parent[rb] = ra
            if rank[ra] == rank[rb]:
                rank[ra] += 1
            return True

        edges = _build_edges(self.width, self.height)
        rng.shuffle(edges)

        for x, y, wall in edges:
            dx, dy = DIRECTION_DELTA[wall]
            nx, ny = x + dx, y + dy
            if union((x, y), (nx, ny)):
                self.carve(x, y, wall)

    def _generate_prim(
        self, rng: MazeRng,
    ) -> None:
        """Generate a perfect maze using Prim's algorithm."""
        in_maze: set[Tuple[int, int]] = set()
        walls: list[Tuple[int, int, int]] = []
        sx = rng.randint(0, self.width - 1)
        sy = rng.randint(0, self.height - 1)
        in_maze.add((sx, sy))
        _add_frontier(self, sx, sy, in_maze, walls)
        while walls:
            idx = rng.randint(0, len(walls) - 1)
            walls[idx], walls[-1] = walls[-1], walls[idx]
            x, y, wall = walls.pop()
            cell = _prim_try_carve(
                self, x, y, wall, in_maze,
            )
            if cell is not None:
                _add_frontier(
                    self, cell[0], cell[1],
                    in_maze, walls,
                )

    def _has_3x3_open(self, x: int, y: int) -> bool:
        """Check if a 3x3 open area exists starting at (x, y).

        A 3x3 area is "open" when all internal walls between
        its 9 cells are removed.

        Args:
            x: Top-left column of the 3x3 region.
            y: Top-left row of the 3x3 region.

        Returns:
            True if the 3x3 region has no internal walls.
        """
        for dy in range(3):
            for dx in range(3):
                cx, cy = x + dx, y + dy
                if dx < 2 and self._get_wall(
                    cx, cy, EAST
                ):
                    return False
                if dy < 2 and self._get_wall(
                    cx, cy, SOUTH
                ):
                    return False
        return True

    def _any_3x3_open(self) -> bool:
        """Check if any 3x3 open area exists in the maze.

        Returns:
            True if at least one 3x3 open area is found.
        """
        for y in range(self.height - 2):
            for x in range(self.width - 2):
                if self._has_3x3_open(x, y):
                    return True
        return False

    def _collect_internal_walls(
        self,
    ) -> list[Tuple[int, int, int]]:
        """Collect removable internal walls."""
        walls: list[Tuple[int, int, int]] = []
        for y in range(self.height):
            for x in range(self.width):
                if (x, y) in self.pattern_cells:
                    continue
                self._try_add_wall(
                    walls, x, y, EAST,
                )
                self._try_add_wall(
                    walls, x, y, SOUTH,
                )
        return walls

    def _try_add_wall(
        self,
        walls: list[Tuple[int, int, int]],
        x: int, y: int, direction: int,
    ) -> None:
        """Add wall to list if it exists and is removable."""
        dx, dy = DIRECTION_DELTA[direction]
        nx, ny = x + dx, y + dy
        if (
            self.in_bounds(nx, ny)
            and self._get_wall(x, y, direction)
            and (nx, ny) not in self.pattern_cells
        ):
            walls.append((x, y, direction))

    def _bfs_came_from(
        self,
        start: Tuple[int, int],
        goal: Tuple[int, int],
    ) -> CameFrom:
        """Run BFS from start and return came-from map.

        Stops early once goal is reached.
        """
        came_from: CameFrom = {start: None}
        queue: deque[Tuple[int, int]] = deque([start])
        while queue:
            x, y = queue.popleft()
            if (x, y) == goal:
                break
            for wall, (dx, dy) in (
                DIRECTION_DELTA.items()
            ):
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in came_from
                ):
                    came_from[(nx, ny)] = (
                        (x, y), wall
                    )
                    queue.append((nx, ny))
        return came_from

    def _is_reachable(
        self,
        start: Tuple[int, int],
        goal: Tuple[int, int],
    ) -> bool:
        """Check if goal is reachable from start via BFS."""
        visited: set[Tuple[int, int]] = {start}
        queue: deque[Tuple[int, int]] = deque([start])
        while queue:
            x, y = queue.popleft()
            if (x, y) == goal:
                return True
            for wall, (dx, dy) in (
                DIRECTION_DELTA.items()
            ):
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in visited
                ):
                    visited.add((nx, ny))
                    queue.append((nx, ny))
        return False

    def _has_multiple_paths(
        self,
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
    ) -> bool:
        """Check if multiple paths exist between entry and exit.

        Finds the shortest path, then tries blocking each
        edge on it. If exit is still reachable with any
        single edge blocked, multiple paths exist.
        """
        came_from = self._bfs_came_from(entry, exit_pos)
        if exit_pos not in came_from:
            return False
        edges: list[Tuple[int, int, int]] = []
        cur = exit_pos
        while came_from[cur] is not None:
            prev, wall = came_from[cur]  # type: ignore
            edges.append((prev[0], prev[1], wall))
            cur = prev
        for ex, ey, ewall in edges:
            self._set_wall(ex, ey, ewall, True)
            reachable = self._is_reachable(
                entry, exit_pos
            )
            self._set_wall(ex, ey, ewall, False)
            if reachable:
                return True
        return False

    def remove_random_walls(
        self,
        rng: Optional[MazeRng] = None,
        entry: Optional[Tuple[int, int]] = None,
        exit_pos: Optional[Tuple[int, int]] = None,
    ) -> None:
        """Remove random internal walls for non-perfect mazes.

        Removes approximately 15% of internal walls while
        ensuring no 3x3 open areas are created.
        When entry and exit are provided, guarantees that
        multiple paths exist between them.
        """
        if rng is None:
            rng = create_rng(self.seed)
        internal_walls = self._collect_internal_walls()

        if not internal_walls:
            raise ValueError(
                "Cannot create non-perfect maze: "
                "no removable walls found. "
                "Increase maze size."
            )
        rng.shuffle(internal_walls)
        target: int = max(
            1, len(internal_walls) * 15 // 100
        )
        removed: int = 0

        for x, y, wall in internal_walls:
            if removed >= target:
                break
            self.carve(x, y, wall)
            if self._any_3x3_open():
                self._set_wall(x, y, wall, True)
            else:
                removed += 1

        if removed == 0:
            raise ValueError(
                "Cannot create non-perfect maze: "
                "all wall removals would create "
                "3x3 open areas. "
                "Increase maze size."
            )

        if (
            entry is not None
            and exit_pos is not None
            and not self._has_multiple_paths(
                entry, exit_pos
            )
        ):
            remaining = self._collect_internal_walls()
            rng.shuffle(remaining)
            for x, y, wall in remaining:
                self.carve(x, y, wall)
                if self._any_3x3_open():
                    self._set_wall(x, y, wall, True)
                    continue
                if self._has_multiple_paths(
                    entry, exit_pos
                ):
                    break

    def solve(
        self,
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
        solver: str = "bfs",
    ) -> str:
        """Find a path from entry to exit.

        Args:
            entry: (x, y) starting position.
            exit_pos: (x, y) ending position.
            solver: Algorithm name (bfs, bibfs, astar).

        Returns:
            Path string using N/E/S/W direction characters.

        Raises:
            ValueError: If no path exists or solver unknown.
        """
        if entry == exit_pos:
            return ""
        if solver == "bfs":
            return self._solve_bfs(entry, exit_pos)
        if solver == "bibfs":
            return self._solve_bibfs(entry, exit_pos)
        if solver == "astar":
            return self._solve_astar(entry, exit_pos)
        raise ValueError(
            f"Unknown solver: {solver!r}. "
            f"Valid: bfs, bibfs, astar"
        )

    def _solve_bfs(
        self,
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
    ) -> str:
        """BFS shortest path solver.

        Args:
            entry: Start position.
            exit_pos: End position.

        Returns:
            Shortest path as direction string.

        Raises:
            ValueError: If no path exists.
        """
        came_from: CameFrom = {entry: None}
        queue: deque[Tuple[int, int]] = deque([entry])

        while queue:
            x, y = queue.popleft()
            if (x, y) == exit_pos:
                return self.reconstruct_path(
                    came_from, exit_pos
                )
            for wall, (dx, dy) in DIRECTION_DELTA.items():
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in came_from
                ):
                    came_from[(nx, ny)] = ((x, y), wall)
                    queue.append((nx, ny))

        raise ValueError(
            f"No path from {entry} to {exit_pos}"
        )

    def _solve_bibfs(
        self,
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
    ) -> str:
        """Bidirectional BFS shortest path solver.

        Searches from both entry and exit simultaneously.
        Guarantees shortest path.

        Args:
            entry: Start position.
            exit_pos: End position.

        Returns:
            Shortest path as direction string.

        Raises:
            ValueError: If no path exists.
        """
        cf_fwd: CameFrom = {entry: None}
        cf_bwd: CameFrom = {exit_pos: None}
        q_fwd: deque[Tuple[int, int]] = deque([entry])
        q_bwd: deque[Tuple[int, int]] = deque(
            [exit_pos]
        )

        while q_fwd and q_bwd:
            # Expand forward
            x, y = q_fwd.popleft()
            if (x, y) in cf_bwd:
                return self.merge_bibfs(
                    cf_fwd, cf_bwd, (x, y)
                )
            for wall, (dx, dy) in (
                DIRECTION_DELTA.items()
            ):
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in cf_fwd
                ):
                    cf_fwd[(nx, ny)] = (
                        (x, y), wall
                    )
                    q_fwd.append((nx, ny))
                    if (nx, ny) in cf_bwd:
                        return self.merge_bibfs(
                            cf_fwd, cf_bwd,
                            (nx, ny),
                        )

            if not q_bwd:
                break
            # Expand backward
            x, y = q_bwd.popleft()
            if (x, y) in cf_fwd:
                return self.merge_bibfs(
                    cf_fwd, cf_bwd, (x, y)
                )
            for wall, (dx, dy) in (
                DIRECTION_DELTA.items()
            ):
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if (
                    self.in_bounds(nx, ny)
                    and (nx, ny) not in cf_bwd
                ):
                    cf_bwd[(nx, ny)] = (
                        (x, y), wall
                    )
                    q_bwd.append((nx, ny))
                    if (nx, ny) in cf_fwd:
                        return self.merge_bibfs(
                            cf_fwd, cf_bwd,
                            (nx, ny),
                        )

        raise ValueError(
            f"No path from {entry} to {exit_pos}"
        )

    def merge_bibfs(
        self,
        cf_fwd: CameFrom,
        cf_bwd: CameFrom,
        meet: Tuple[int, int],
    ) -> str:
        """Merge forward and backward BFS trees.

        Args:
            cf_fwd: Forward came-from map.
            cf_bwd: Backward came-from map.
            meet: Meeting point cell.

        Returns:
            Complete path as direction string.
        """
        # Forward half: entry -> meet
        fwd_part: str = self.reconstruct_path(
            cf_fwd, meet
        )
        # Backward half: meet -> exit
        bwd_dirs: list[str] = []
        cur = meet
        while cf_bwd[cur] is not None:
            parent, wall = cf_bwd[cur]  # type: ignore
            bwd_dirs.append(
                DIRECTION_LETTER[OPPOSITE[wall]]
            )
            cur = parent
        return fwd_part + "".join(bwd_dirs)

    def _solve_astar(
        self,
        entry: Tuple[int, int],
        exit_pos: Tuple[int, int],
    ) -> str:
        """A* shortest path solver with Manhattan heuristic.

        Args:
            entry: Start position.
            exit_pos: End position.

        Returns:
            Shortest path as direction string.

        Raises:
            ValueError: If no path exists.
        """
        came_from: CameFrom = {entry: None}
        g: dict[Tuple[int, int], int] = {entry: 0}
        counter: int = 0
        open_set: list[Tuple[int, int, int, int]] = [
            (_manhattan(entry, exit_pos),
             counter, entry[0], entry[1])
        ]

        while open_set:
            _, _, x, y = heapq.heappop(open_set)
            if (x, y) == exit_pos:
                return self.reconstruct_path(
                    came_from, exit_pos
                )
            cg: int = g[(x, y)]
            for wall, (dx, dy) in DIRECTION_DELTA.items():
                if self.grid[y][x] & wall:
                    continue
                nx, ny = x + dx, y + dy
                if not self.in_bounds(nx, ny):
                    continue
                if (
                    (nx, ny) not in g
                    or cg + 1 < g[(nx, ny)]
                ):
                    g[(nx, ny)] = cg + 1
                    came_from[(nx, ny)] = ((x, y), wall)
                    counter += 1
                    heapq.heappush(
                        open_set,
                        (cg + 1 + _manhattan(
                            (nx, ny), exit_pos),
                         counter, nx, ny),
                    )

        raise ValueError(
            f"No path from {entry} to {exit_pos}"
        )

    def reconstruct_path(
        self,
        came_from: CameFrom,
        target: Tuple[int, int],
    ) -> str:
        """Reconstruct the BFS path as direction characters.

        Args:
            came_from: BFS parent map.
            target: The destination cell.

        Returns:
            Direction string (e.g. 'SSENES...').
        """
        path: list[str] = []
        current: Tuple[int, int] = target
        while came_from[current] is not None:
            prev, wall = came_from[current]  # type: ignore
            path.append(DIRECTION_LETTER[wall])
            current = prev
        path.reverse()
        return "".join(path)
