*This project has been created as part of the 42 curriculum by tomuraka, diwamoto*

# A-Maze-ing

A Python maze generator that creates random mazes from a configuration file, outputs hexadecimal wall encoding, and provides both ASCII and graphical (MLX) visual displays.

## Description

A-Maze-ing generates random mazes using configurable algorithms (Recursive Backtracker, Kruskal's, or Prim's). It supports perfect mazes (spanning trees with exactly one path between any two cells) and imperfect mazes with multiple paths. The program:

- Reads maze parameters from a configuration file
- Generates a valid maze with proper wall encoding
- Embeds a visible "42" pattern using fully-closed cells
- Solves the maze using BFS to find the shortest path
- Writes the result in hexadecimal format
- Displays the maze visually with interactive controls

## Instructions

### Prerequisites

- Python 3.10 or later
- pip package manager

### Installation

```bash
make install
```

This installs `flake8`, `mypy`, `build`, and the `mazegen` package in development mode. It also attempts to install the MLX library for graphical display.

### Running

```bash
make run
```

Or directly:

```bash
python3 a_maze_ing.py config.txt
```

### Other Commands

```bash
make debug      # Run with Python debugger (pdb)
make clean      # Remove __pycache__, .mypy_cache, build artifacts
make lint       # Run flake8 and mypy checks
make build      # Build the mazegen package (.whl and .tar.gz)
```

## Resources

- [Maze Generation Algorithms — Wikipedia](https://en.wikipedia.org/wiki/Maze_generation_algorithm)
- [Spanning Tree — Wikipedia](https://en.wikipedia.org/wiki/Spanning_tree)
- [Think Labyrinth — Maze Algorithms](http://www.astrolog.org/labyrnth/algrithm.htm)
- [BFS Shortest Path](https://en.wikipedia.org/wiki/Breadth-first_search)

### AI Usage

AI tools were used for:
- Generating boilerplate code structure and scaffolding
- Writing docstrings and documentation
- Debugging edge cases in wall encoding consistency
- Reviewing algorithm implementations for correctness

All AI-generated content was reviewed, understood, and validated by the team.

## Config File Format

The configuration file uses `KEY=VALUE` format, one entry per line. Lines starting with `#` are comments.

### Mandatory Keys

| Key | Description | Example |
|-----|-------------|---------|
| `WIDTH` | Maze width (cells) | `WIDTH=20` |
| `HEIGHT` | Maze height (cells) | `HEIGHT=15` |
| `ENTRY` | Entry coordinates (x,y) | `ENTRY=0,0` |
| `EXIT` | Exit coordinates (x,y) | `EXIT=19,14` |
| `OUTPUT_FILE` | Output filename | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | Perfect maze flag | `PERFECT=True` |

### Optional Keys

| Key | Description | Default |
|-----|-------------|---------|
| `SEED` | Random seed for reproducibility | Random |
| `ALGORITHM` | Generation algorithm | `recursive_backtracker` |
| `DISPLAY` | Display mode (`ascii`, `mlx`) | `mlx` |
| `SOLVER` | Pathfinding algorithm (`bfs`, `bibfs`, `astar`) | `bfs` |

### Example

```
# My maze config
WIDTH=20
HEIGHT=15
ENTRY=0,0
EXIT=19,14
OUTPUT_FILE=maze.txt
PERFECT=True
SEED=42
ALGORITHM=recursive_backtracker
# DISPLAY: mlx (default) or ascii
# SOLVER: bfs (default), bibfs, or astar
```

## Algorithm

### Recursive Backtracker (Default)

The recursive backtracker (iterative DFS) is the default algorithm. It works by:

1. Starting from a random cell with all walls closed
2. Choosing a random unvisited neighbour and carving a passage
3. Backtracking when no unvisited neighbours remain
4. Continuing until all cells are visited

**Why this algorithm?** It naturally produces perfect mazes (spanning trees) with long, winding corridors and a good aesthetic. It's simple to implement, efficient (O(cells)), and produces mazes with a good balance of difficulty.

### Alternative Algorithms

- **Kruskal's**: Treats walls as edges and uses union-find to merge sets. Produces more "uniform" mazes with shorter corridors. Selected via `ALGORITHM=kruskal`.
- **Prim's**: Grows the maze from a single point by selecting random frontier walls. Creates radial patterns centered around the starting cell. Selected via `ALGORITHM=prim`.

## Reusable Module

The maze generation logic is packaged as `mazegen`, a standalone pip-installable module.

### Building

```bash
make build
```

This produces `mazegen-1.0.0-py3-none-any.whl` and `mazegen-1.0.0.tar.gz` at the repository root.

### Installation

```bash
pip install mazegen-1.0.0-py3-none-any.whl
```

### Usage

```python
from mazegen import MazeGenerator

# Create a generator
gen = MazeGenerator(width=20, height=15, seed=42, perfect=True)

# Generate the maze
gen.generate()

# Access the grid (2D list of 4-bit wall-encoded integers)
grid = gen.grid  # grid[y][x] is a 0-15 value

# Solve the maze (bfs, bibfs, or astar)
path = gen.solve(entry=(0, 0), exit_pos=(19, 14))
print(path)  # e.g., 'SSEESSWW...'

# Use a different solver
path_bibfs = gen.solve((0, 0), (19, 14), solver='bibfs')
path_astar = gen.solve((0, 0), (19, 14), solver='astar')

# Non-perfect maze (multiple paths guaranteed)
gen2 = MazeGenerator(width=20, height=15, seed=42, perfect=False)
gen2.generate()
gen2.remove_random_walls(entry=(0, 0), exit_pos=(19, 14))
path2 = gen2.solve(entry=(0, 0), exit_pos=(19, 14))
```

### Parameters

- `width` (int): Number of cells horizontally
- `height` (int): Number of cells vertically
- `seed` (int, optional): Random seed for reproducibility
- `perfect` (bool): If True, generates a spanning-tree maze
- `algorithm` (str): `"recursive_backtracker"`, `"kruskal"`, or `"prim"`

### Wall Encoding

Each cell is a 4-bit integer (0x0–0xF):

| Bit | Direction |
|-----|-----------|
| 0 (LSB) | North |
| 1 | East |
| 2 | South |
| 3 (MSB) | West |

Closed wall = bit set to 1.

## Visual Display

### ASCII Mode

Terminal-based rendering with ANSI colours. Shows walls, entry (E), exit (X), solution path (·), and the "42" pattern in colour.

**Controls:**
- `r` — Regenerate maze (increment seed)
- `p` — Toggle path visibility
- `c` — Cycle wall colours
- `t` — Cycle "42" pattern colours
- `s` — Set a custom seed
- `g` — Cycle generation algorithm (recursive_backtracker → kruskal → prim)
- `f` — Cycle solving algorithm (bfs → bibfs → astar)
- `x` — Toggle perfect/imperfect mode
- `a` — Animate maze generation
- `v` — Animate solve
- `q` — Quit

### MLX Mode

Graphical window using the MiniLibX library. Requires MLX wheel installation.

**Controls:**
- `r` — Regenerate maze
- `p` — Toggle path visibility
- `c` — Cycle wall colours
- `t` — Cycle "42" pattern colours
- `s` — Set custom seed
- `g` — Cycle generation algorithm
- `f` — Cycle solving algorithm
- `x` — Toggle perfect/imperfect mode
- `a` — Animate maze generation
- `v` — Animate solve
- `q` / `Escape` — Quit

## Bonus Features

1. **Multiple generation algorithms**: Supports Recursive Backtracker, Kruskal's, and Prim's algorithms, selectable via config or `g` key at runtime
2. **Multiple solving algorithms**: Supports BFS (shortest path), Bidirectional BFS (shortest path, searches from both ends), and A* (shortest path with heuristic), selectable via config or `f` key at runtime
3. **Generation animation**: Press `a` to watch the maze being carved wall-by-wall in real time
4. **Solution animation**: Press `v` to visualize the solver’s exploration wavefront, then see the path traced back
5. **Live config editing**: Change any setting (seed, algorithm, solver, perfect mode) on the fly without restarting — press `s`/`g`/`f`/`x`

## Team Management

### Roles

- **tomuraka**: Project lead, core algorithm implementation, maze generation
- **diwamoto**: Display modules, testing, documentation and packaging

### Planning

The project was developed in phases:
1. Core maze generation (algorithms, wall encoding)
2. Configuration parsing and output file format
3. Visual display (ASCII + MLX)
4. "42" pattern placement
5. Bonus features
6. Documentation and packaging

### Retrospective

**What worked well:**
- Modular architecture allowing independent testing of components
- Clear separation between generation logic and display
- Seed-based reproducibility for debugging

**What could be improved:**
- Earlier integration testing between components
- More comprehensive edge case testing for small mazes

### Tools Used

- Python 3.10+
- flake8 (linting)
- mypy (type checking)
- pytest (testing)
- MiniLibX (graphical display)
- Git (version control)
